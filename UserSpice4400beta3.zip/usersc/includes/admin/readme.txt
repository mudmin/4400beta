If you put a file in here with the same name as the corresponding view from admin.php, yours will be loaded instead of ours
